/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "pid.h"
#include "Cam.h"
#include "receive.h"
#include "stdio.h"
#include  "usart.h"
#include "cJSON.h"
#include "stdlib.h"
#include "string.h"
#include "motor.h"
#include "BMI088driver.h"
#include "Gyroscope.h"
#include "Referee_system.h"
#include "Damiao.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
cJSON *cJsonData ,*cJsonVlaue;//cjson
float p,i,d,a;//cjson��pid
int Motor_RMP;
int teat_Val;
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId Car_ControlHandle;
osThreadId Pid_TaskHandle;
osThreadId SPIHandle;
osThreadId Referee_dataHandle;
osThreadId Send_Data_DamiaHandle;
osThreadId Recive_Damiao_DHandle;
osMessageQId Queue_Data_SendHandle;
osSemaphoreId Needed_Referee_dataHandle;
osSemaphoreId Damiao_Data_DealHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void Chassis_Settlement(void const * argument);
void Pid_Change(void const * argument);
void Acc(void const * argument);
void Referee_data_Deal(void const * argument);
void Usart_Send_Data(void const * argument);
void Damiao_Recive(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* GetTimerTaskMemory prototype (linked to static allocation support) */
void vApplicationGetTimerTaskMemory( StaticTask_t **ppxTimerTaskTCBBuffer, StackType_t **ppxTimerTaskStackBuffer, uint32_t *pulTimerTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/* USER CODE BEGIN GET_TIMER_TASK_MEMORY */
static StaticTask_t xTimerTaskTCBBuffer;
static StackType_t xTimerStack[configTIMER_TASK_STACK_DEPTH];

void vApplicationGetTimerTaskMemory( StaticTask_t **ppxTimerTaskTCBBuffer, StackType_t **ppxTimerTaskStackBuffer, uint32_t *pulTimerTaskStackSize )
{
  *ppxTimerTaskTCBBuffer = &xTimerTaskTCBBuffer;
  *ppxTimerTaskStackBuffer = &xTimerStack[0];
  *pulTimerTaskStackSize = configTIMER_TASK_STACK_DEPTH;
  /* place for user code */
}
/* USER CODE END GET_TIMER_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of Needed_Referee_data */
  osSemaphoreDef(Needed_Referee_data);
  Needed_Referee_dataHandle = osSemaphoreCreate(osSemaphore(Needed_Referee_data), 1);

  /* definition and creation of Damiao_Data_Deal */
  osSemaphoreDef(Damiao_Data_Deal);
  Damiao_Data_DealHandle = osSemaphoreCreate(osSemaphore(Damiao_Data_Deal), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of Queue_Data_Send */
  osMessageQDef(Queue_Data_Send, 256, uint8_t);
  Queue_Data_SendHandle = osMessageCreate(osMessageQ(Queue_Data_Send), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of Car_Control */
  osThreadDef(Car_Control, Chassis_Settlement, osPriorityNormal, 0, 128);
  Car_ControlHandle = osThreadCreate(osThread(Car_Control), NULL);

  /* definition and creation of Pid_Task */
  osThreadDef(Pid_Task, Pid_Change, osPriorityNormal, 0, 128);
  Pid_TaskHandle = osThreadCreate(osThread(Pid_Task), NULL);

  /* definition and creation of SPI */
  osThreadDef(SPI, Acc, osPriorityHigh, 0, 128);
  SPIHandle = osThreadCreate(osThread(SPI), NULL);

  /* definition and creation of Referee_data */
  osThreadDef(Referee_data, Referee_data_Deal, osPriorityNormal, 0, 128);
  Referee_dataHandle = osThreadCreate(osThread(Referee_data), NULL);

  /* definition and creation of Send_Data_Damia */
  osThreadDef(Send_Data_Damia, Usart_Send_Data, osPriorityNormal, 0, 128);
  Send_Data_DamiaHandle = osThreadCreate(osThread(Send_Data_Damia), NULL);

  /* definition and creation of Recive_Damiao_D */
  osThreadDef(Recive_Damiao_D, Damiao_Recive, osPriorityNormal, 0, 128);
  Recive_Damiao_DHandle = osThreadCreate(osThread(Recive_Damiao_D), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_Chassis_Settlement */
/**
  * @brief  Function implementing the Car_Control thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_Chassis_Settlement */
void Chassis_Settlement(void const * argument)
{
  /* USER CODE BEGIN Chassis_Settlement */
  /* Infinite loop */
  for(;;)
  {
      //printf("%d\n",Motor_measure[0].speed);
     Motor[MOTOR_A].CurrenT_Output=Speed_Low_Filter(PID_calc(&Motor[MOTOR_A],Motor_measure[MOTOR_A].speed,McNamara_Wheel_Settlement(MOTOR_A,Out_Eight_Mode)),Motor[MOTOR_A].Speed_record);
     Motor[MOTOR_B].CurrenT_Output=Speed_Low_Filter(PID_calc(&Motor[MOTOR_B],Motor_measure[MOTOR_B].speed,McNamara_Wheel_Settlement(MOTOR_B,Out_Eight_Mode)),Motor[MOTOR_B].Speed_record);
     Motor[MOTOR_C].CurrenT_Output=Speed_Low_Filter(PID_calc(&Motor[MOTOR_C],Motor_measure[MOTOR_C].speed,-McNamara_Wheel_Settlement(MOTOR_C,Out_Eight_Mode)),Motor[MOTOR_C].Speed_record);
     Motor[MOTOR_D].CurrenT_Output=Speed_Low_Filter(PID_calc(&Motor[MOTOR_D],Motor_measure[MOTOR_D].speed,-McNamara_Wheel_Settlement(MOTOR_D,Out_Eight_Mode)),Motor[MOTOR_D].Speed_record);
     Set_motor_cmd( Motor[MOTOR_A].CurrenT_Output,Motor[MOTOR_B].CurrenT_Output,Motor[MOTOR_C].CurrenT_Output,Motor[MOTOR_D].CurrenT_Output);
     osDelay(2);
  }
  /* USER CODE END Chassis_Settlement */
}

/* USER CODE BEGIN Header_Pid_Change */
/**
* @brief Function implementing the Pid_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Pid_Change */
void Pid_Change(void const * argument)
{
  /* USER CODE BEGIN Pid_Change */
  /* Infinite loop */
  for(;;)
  {
      if(Usart_WaitReasFinish() == 0)//�Ƿ�������
    {
    cJsonData = cJSON_Parse((const char *)Usart2_ReadBuf);
    if(cJSON_GetObjectItem(cJsonData,"p") !=NULL)
    {
    cJsonVlaue = cJSON_GetObjectItem(cJsonData,"p");
    p = cJsonVlaue->valuedouble;
    Motor[0].Kp = p;
    }
    if(cJSON_GetObjectItem(cJsonData,"i") !=NULL)
    {
    cJsonVlaue = cJSON_GetObjectItem(cJsonData,"i");
    i = cJsonVlaue->valuedouble;
    Motor[0].Ki = i;
    }
    if(cJSON_GetObjectItem(cJsonData,"d") !=NULL)
    {
    cJsonVlaue = cJSON_GetObjectItem(cJsonData,"d");
    d = cJsonVlaue->valuedouble;
    Motor[0].Kd = d;
    }
    if(cJSON_GetObjectItem(cJsonData,"a") !=NULL)
    {
    cJsonVlaue = cJSON_GetObjectItem(cJsonData,"a");
    a = cJsonVlaue->valuedouble;
    Motor[0].Max_iout =a;
    }
    if(cJsonData != NULL){
    cJSON_Delete(cJsonData);//�ͷſռ䡢���ǲ���ɾ��cJsonVlaue��Ȼ�� �����쳣����
    }
    memset(Usart2_ReadBuf,0,255);//��ս���buf��ע�����ﲻ��ʹ��strlen
    }   
    osDelay(10);
  }
  /* USER CODE END Pid_Change */
}

/* USER CODE BEGIN Header_Acc */
/**
* @brief Function implementing the SPI thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Acc */
void Acc(void const * argument)
{
  /* USER CODE BEGIN Acc */
  /* Infinite loop */
  for(;;)
  {
      BMI088_read(Bmi_Data.gyro, Bmi_Data.accel, &Bmi_Data.temp);
      MahonyAHRSupdateIMU(Bmi_Data.q,Bmi_Data.gyro[0],Bmi_Data.gyro[1],Bmi_Data.gyro[2],Bmi_Data.accel[0],Bmi_Data.accel[1],Bmi_Data.accel[2]);
      get_angle(Bmi_Data.q,&Bmi_Data.INS_angle[0],&Bmi_Data.INS_angle[1],&Bmi_Data.INS_angle[2]);
      osDelay(10);
  }
  /* USER CODE END Acc */
}

/* USER CODE BEGIN Header_Referee_data_Deal */
/**
* @brief Function implementing the Referee_data thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Referee_data_Deal */
void Referee_data_Deal(void const * argument)
{
  /* USER CODE BEGIN Referee_data_Deal */
  /* Infinite loop */
  for(;;)
  {
      uint16_t Com_Val;
      xSemaphoreTake(Needed_Referee_dataHandle,portMAX_DELAY);
      Com_Val=((uint16_t)Referee_data.Usart6_Rx_Buff[5] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[6];//�ó����ݵ�ָ��
      Extract_Referee_Info(Com_Val);
      osDelay(20);
     
/*      
      ���з��͵ķ�ʽ����������һ����
      uint8_t Ref_Rec_Buff[UART6_RX_BUF_SIZE];
      if (pdPASS == xQueueReceive(Queue_Data_SendHandle, Ref_Rec_Buff, portMAX_DELAY))
      Com_Val=((uint16_t)Referee_data.Usart6_Rx_Buff_Copy[5] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff_Copy[6];//�ó����ݵ�ָ��
      Que_Extract_Referee_Info(Ref_Rec_Buff,Com_Val);
      osDelay(20);
 */
  }
     
  /* USER CODE END Referee_data_Deal */
}

/* USER CODE BEGIN Header_Usart_Send_Data */
/**
* @brief Function implementing the Send_Data_Damia thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Usart_Send_Data */
void Usart_Send_Data(void const * argument)
{
  /* USER CODE BEGIN Usart_Send_Data */
  /* Infinite loop */
  for(;;)
  {
    Send_Data_To_Damiao();
      osDelay(20);
  }
  /* USER CODE END Usart_Send_Data */
}

/* USER CODE BEGIN Header_Damiao_Recive */
/**
* @brief Function implementing the Recive_Damiao_D thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Damiao_Recive */
void Damiao_Recive(void const * argument)
{
  /* USER CODE BEGIN Damiao_Recive */
  /* Infinite loop */
  for(;;)
  {
       xSemaphoreTake(Damiao_Data_DealHandle,portMAX_DELAY);
       memcpy(Damiao_Data_Rec.Usart1_Rx_Buff_Copy, Damiao_Data_Rec.Usart1_Rx_Buff, sizeof(Damiao_Data_Rec.Usart1_Rx_Buff));
       memset(Damiao_Data_Rec.Usart1_Rx_Buff, 0, sizeof(Damiao_Data_Rec.Usart1_Rx_Buff));          //��ս��ջ�����
        Damiao_Data_Rec.Usart1_Rx_Index = 0; 
       osDelay(20);
        HAL_UART_Receive_DMA(Damiao_Usart,Damiao_Data_Rec.Usart1_Rx_Buff ,UART1_RX_BUF_SIZE);//����DMA���գ����ڴ�������ϵͳ����
       
  }
  /* USER CODE END Damiao_Recive */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */



    /*
typedef _packed struct 
{ 
 uint8_t robot_id; 
 uint8_t robot_level; 
 uint16_t current_HP; 
 uint16_t maximum_HP; 
 uint16_t shooter_barrel_cooling_value; 
 uint16_t shooter_barrel_heat_limit; 
 uint16_t chassis_power_limit; 
 uint8_t power_management_gimbal_output : 1; 
 uint8_t power_management_chassis_output : 1; 
 uint8_t power_management_shooter_output : 1; 
}robot_status_t;
    */

/* USER CODE END Application */

