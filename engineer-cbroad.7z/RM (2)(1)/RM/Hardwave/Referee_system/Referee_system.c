#include "Referee_system.h"
#include "stdio.h"
#include "string.h"
#include "usart.h"
#include "receive.h"


Usart_Referee_data Referee_data;
Com_Id Com_Referee;
RobotInfo Robot_All_Info; 

#define CRC8_POLYNOMIAL 0x07  // ������ CRC-8 ����ʽ��x^8 + x^2 + x + 1��
#define CRC16_POLYNOMIAL 0x8005

uint8_t frame_header_crc_check(uint8_t *data)
{
    uint8_t Crc8_Val;         // �������� CRC ֵ
    uint8_t Crc8_Cal = 0x00;  // ���ڼ�������� CRC
    uint8_t Frame_Data[5];
    // �ӽ��ջ��������� 5 ���ֽ����ݵ� Frame_Data
    memcpy(Frame_Data, Referee_data.Usart6_Rx_Buff, 5 * sizeof(uint8_t));
    // ��ȡ���͹����� CRC ֵ�����һ���ֽڣ�
    Crc8_Val = Frame_Data[4];
    // ��ǰ 4 ���ֽڽ��� CRC8 У�����
    for (int i = 0; i < 4; i++) {
        Crc8_Cal ^= data[i];  // �������뵱ǰ CRC �����      
        // �Ե�ǰ�ֽڵ�ÿһλ���� CRC ����
        for (uint8_t bit = 0; bit < 8; bit++) {
            if (Crc8_Cal & 0x80) {
                // ������λΪ 1�����Ʋ�������ʽ
                Crc8_Cal = (Crc8_Cal << 1) ^ CRC8_POLYNOMIAL;
            } else {
                // ����ֻ������
                Crc8_Cal <<= 1;
            }
        }
    }
    // �Ƚϼ������ CRC8 ֵ����յ��� CRC8 ֵ������ 1 ��ʾƥ�䣬0 ��ʾ��ƥ��
    return (Crc8_Cal == Crc8_Val) ? 1 : 0;
}


uint16_t Referee_data_check(uint8_t *data)
{
    uint16_t Crc16_Val;         // �������� CRC У��ֵ
    uint16_t Crc16_Cal = 0xFFFF; // CRC16 У��ĳ�ʼֵ
    // ��ȡ CRC У��ֵ������ CRC �洢����������ֽ�
    Crc16_Val = (data[Referee_data.Usart6_Rx_Index - 2] << 8) | data[Referee_data.Usart6_Rx_Index - 1];
    // ���� CRC16 У��ֵ
    for (size_t i = 0; i < Referee_data.Usart6_Rx_Index - 1; i++) {
        Crc16_Cal ^= data[i]; // �����ݵ�ÿ���ֽ��� CRC �����   
        // ��ÿ���ֽڵ�ÿһλ���м���
        for (uint8_t bit = 0; bit < 8; bit++) {
            if (Crc16_Cal & 0x8000) { // ������λΪ 1
                Crc16_Cal = (Crc16_Cal << 1) ^ CRC16_POLYNOMIAL; // ���Ʋ�������ʽ
            } else {
                Crc16_Cal <<= 1; // ����ֻ������
            }
        }
    }
    // ���ؽ�����жϼ���� CRC16 �Ƿ����ȡ�� CRC16 ƥ��
    return (Crc16_Cal == Crc16_Val) ? 1 : 0;
}

void Extract_Referee_Info(Com_Id Cmd)
{
    // ȷ��a����ʼ��
    uint8_t index;
    switch(Cmd)
    {
        case game_robot_state:
            index = 7;
            // ʹ��ǿ������ת����ȷ����λ�������ᷢ�����Ͳ�ƥ��
            Robot_All_Info.Robot_Data.red_1_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.red_2_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.red_3_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.red_4_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.reserved1 = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.red_7_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.red_outpost_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.red_base_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.blue_1_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.blue_2_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.blue_3_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.blue_4_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.reserved2 = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.blue_7_robot_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.blue_outpost_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.Robot_Data.blue_base_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            break;

        case event_data:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.event_data.event_data = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                    ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                    ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                    (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            break;

        case dart_info:
            index = 7;
            Robot_All_Info.dart_info.dart_remaining_time = Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.dart_info.dart_info = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            break;

        case robot_status:
            index = 7;
            Robot_All_Info.robot_status.robot_id = Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.robot_level = Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.current_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.maximum_HP = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.shooter_barrel_cooling_value = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.shooter_barrel_heat_limit = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.chassis_power_limit = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.power_management_gimbal_output = Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.power_management_chassis_output = Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_status.power_management_shooter_output = Referee_data.Usart6_Rx_Buff[index++];
            break;

        case power_heat_data:
            index = 7;
            Robot_All_Info.power_heat_data.reserved1 = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.power_heat_data.reserved2 = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.power_heat_data.reserved3 = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                        ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                        ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                        (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.power_heat_data.buffer_energy = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.power_heat_data.shooter_17mm_1_barrel_heat = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.power_heat_data.shooter_17mm_2_barrel_heat = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.power_heat_data.shooter_42mm_barrel_heat = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            break;

        case robot_pos:
            index = 7;
            Robot_All_Info.robot_pos.x = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                          ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                          ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                          (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_pos.y = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                          ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                          ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                          (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.robot_pos.angle = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                             ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                             ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                             (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            break;

        case hurt_data:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.hurt_data.armor_id = Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.hurt_data.HP_deduction_reason = Referee_data.Usart6_Rx_Buff[index++];
            break;

        case projectile_allowance:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.projectile_allowance.projectile_allowance_17mm = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.projectile_allowance.projectile_allowance_42mm = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.projectile_allowance.remaining_gold_coin = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            break;

        case rfid_status:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.rfid_status.rfid_status = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                    ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                    ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                    (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            break;

        case dart_client_cmd:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.dart_client_cmd.dart_launch_opening_status = Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.dart_client_cmd.reserved = Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.dart_client_cmd.target_change_time = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.dart_client_cmd.latest_launch_cmd_time = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            break;
             
        case ground_robot_position:
            index = 7;
            // ��� hero_x λ��
            Robot_All_Info.ground_robot_position.hero_x = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                           ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                           ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                           (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� hero_y λ��
            Robot_All_Info.ground_robot_position.hero_y = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                           ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                           ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                           (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� engineer_x λ��
            Robot_All_Info.ground_robot_position.engineer_x = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                              ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                              ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                              (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� engineer_y λ��
            Robot_All_Info.ground_robot_position.engineer_y = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                              ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                              ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                              (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� standard_3_x λ��
            Robot_All_Info.ground_robot_position.standard_3_x = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                                 ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                                 ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                                 (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� standard_3_y λ��
            Robot_All_Info.ground_robot_position.standard_3_y = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                                 ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                                 ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                                 (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� standard_4_x λ��
            Robot_All_Info.ground_robot_position.standard_4_x = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                                 ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                                 ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                                 (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� standard_4_y λ��
            Robot_All_Info.ground_robot_position.standard_4_y = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                                 ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                                 ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                                 (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� reserved1 ֵ
            Robot_All_Info.ground_robot_position.reserved1 = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                              ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                              ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                              (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            // ��� reserved2 ֵ
            Robot_All_Info.ground_robot_position.reserved2 = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                              ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                              ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                              (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            break;
        case radar_mark_data:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.radar_mark_data.mark_progress = Referee_data.Usart6_Rx_Buff[index++];
            break;            

        case sentry_info:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.sentry_info.sentry_info = ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 24) |
                                                           ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 16) |
                                                           ((uint32_t)Referee_data.Usart6_Rx_Buff[index++] << 8) |
                                                           (uint32_t)Referee_data.Usart6_Rx_Buff[index++];
            Robot_All_Info.sentry_info.sentry_info_2 = ((uint16_t)Referee_data.Usart6_Rx_Buff[index++] << 8) | (uint16_t)Referee_data.Usart6_Rx_Buff[index++];
            break;
        
        case radar_info:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.radar_info.radar_info = Referee_data.Usart6_Rx_Buff[index++];
            break;

        default://���������Ҫ��ָ���գ����½���
     memset(Referee_data.Usart6_Rx_Buff, 0, sizeof(Referee_data.Usart6_Rx_Buff));          //��ս��ջ�����
    Referee_data.Usart6_Rx_Index = 0; 
    HAL_UART_Receive_DMA(Referee_system_Usart,Referee_data.Usart6_Rx_Buff ,UART6_RX_BUF_SIZE);//����DMA���գ����ڴ�������ϵͳ����
    }//�������Ҫ�����ݣ��������˶���������
     memset(Referee_data.Usart6_Rx_Buff, 0, sizeof(Referee_data.Usart6_Rx_Buff));          //��ս��ջ�����
    Referee_data.Usart6_Rx_Index = 0; 
    HAL_UART_Receive_DMA(Referee_system_Usart,Referee_data.Usart6_Rx_Buff ,UART6_RX_BUF_SIZE);//����DMA���գ����ڴ�������ϵͳ����    
}





void Que_Extract_Referee_Info(uint8_t *Data,Com_Id Cmd)
{
    // ȷ��a����ʼ��
    uint8_t index;
    switch(Cmd)
    {
        case game_robot_state:
            index = 7;
            // ʹ��ǿ������ת����ȷ����λ�������ᷢ�����Ͳ�ƥ��
            Robot_All_Info.Robot_Data.red_1_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.red_2_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.red_3_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.red_4_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.reserved1 = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.red_7_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.red_outpost_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.red_base_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.blue_1_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.blue_2_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.blue_3_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.blue_4_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.reserved2 = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.blue_7_robot_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.blue_outpost_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.Robot_Data.blue_base_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            break;

        case event_data:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.event_data.event_data = ((uint32_t)Data[index++] << 24) |
                                                    ((uint32_t)Data[index++] << 16) |
                                                    ((uint32_t)Data[index++] << 8) |
                                                    (uint32_t)Data[index++];
            break;

        case dart_info:
            index = 7;
            Robot_All_Info.dart_info.dart_remaining_time = Data[index++];
            Robot_All_Info.dart_info.dart_info = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            break;

        case robot_status:
            index = 7;
            Robot_All_Info.robot_status.robot_id = Data[index++];
            Robot_All_Info.robot_status.robot_level = Data[index++];
            Robot_All_Info.robot_status.current_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.robot_status.maximum_HP = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.robot_status.shooter_barrel_cooling_value = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.robot_status.shooter_barrel_heat_limit = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.robot_status.chassis_power_limit = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.robot_status.power_management_gimbal_output = Data[index++];
            Robot_All_Info.robot_status.power_management_chassis_output = Data[index++];
            Robot_All_Info.robot_status.power_management_shooter_output = Data[index++];
            break;

        case power_heat_data:
            index = 7;
            Robot_All_Info.power_heat_data.reserved1 = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.power_heat_data.reserved2 = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.power_heat_data.reserved3 = ((uint32_t)Data[index++] << 24) |
                                                        ((uint32_t)Data[index++] << 16) |
                                                        ((uint32_t)Data[index++] << 8) |
                                                        (uint32_t)Data[index++];
            Robot_All_Info.power_heat_data.buffer_energy = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.power_heat_data.shooter_17mm_1_barrel_heat = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.power_heat_data.shooter_17mm_2_barrel_heat = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.power_heat_data.shooter_42mm_barrel_heat = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            break;

        case robot_pos:
            index = 7;
            Robot_All_Info.robot_pos.x = ((uint32_t)Data[index++] << 24) |
                                          ((uint32_t)Data[index++] << 16) |
                                          ((uint32_t)Data[index++] << 8) |
                                          (uint32_t)Data[index++];
            Robot_All_Info.robot_pos.y = ((uint32_t)Data[index++] << 24) |
                                          ((uint32_t)Data[index++] << 16) |
                                          ((uint32_t)Data[index++] << 8) |
                                          (uint32_t)Data[index++];
            Robot_All_Info.robot_pos.angle = ((uint32_t)Data[index++] << 24) |
                                             ((uint32_t)Data[index++] << 16) |
                                             ((uint32_t)Data[index++] << 8) |
                                             (uint32_t)Data[index++];
            break;

        case hurt_data:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.hurt_data.armor_id = Data[index++];
            Robot_All_Info.hurt_data.HP_deduction_reason = Data[index++];
            break;

        case projectile_allowance:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.projectile_allowance.projectile_allowance_17mm = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.projectile_allowance.projectile_allowance_42mm = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.projectile_allowance.remaining_gold_coin = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            break;

        case rfid_status:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.rfid_status.rfid_status = ((uint32_t)Data[index++] << 24) |
                                                    ((uint32_t)Data[index++] << 16) |
                                                    ((uint32_t)Data[index++] << 8) |
                                                    (uint32_t)Data[index++];
            break;

        case dart_client_cmd:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.dart_client_cmd.dart_launch_opening_status = Data[index++];
            Robot_All_Info.dart_client_cmd.reserved = Data[index++];
            Robot_All_Info.dart_client_cmd.target_change_time = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            Robot_All_Info.dart_client_cmd.latest_launch_cmd_time = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            break;
             
        case ground_robot_position:
            index = 7;
            // ��� hero_x λ��
            Robot_All_Info.ground_robot_position.hero_x = ((uint32_t)Data[index++] << 24) |
                                                           ((uint32_t)Data[index++] << 16) |
                                                           ((uint32_t)Data[index++] << 8) |
                                                           (uint32_t)Data[index++];
            // ��� hero_y λ��
            Robot_All_Info.ground_robot_position.hero_y = ((uint32_t)Data[index++] << 24) |
                                                           ((uint32_t)Data[index++] << 16) |
                                                           ((uint32_t)Data[index++] << 8) |
                                                           (uint32_t)Data[index++];
            // ��� engineer_x λ��
            Robot_All_Info.ground_robot_position.engineer_x = ((uint32_t)Data[index++] << 24) |
                                                              ((uint32_t)Data[index++] << 16) |
                                                              ((uint32_t)Data[index++] << 8) |
                                                              (uint32_t)Data[index++];
            // ��� engineer_y λ��
            Robot_All_Info.ground_robot_position.engineer_y = ((uint32_t)Data[index++] << 24) |
                                                              ((uint32_t)Data[index++] << 16) |
                                                              ((uint32_t)Data[index++] << 8) |
                                                              (uint32_t)Data[index++];
            // ��� standard_3_x λ��
            Robot_All_Info.ground_robot_position.standard_3_x = ((uint32_t)Data[index++] << 24) |
                                                                 ((uint32_t)Data[index++] << 16) |
                                                                 ((uint32_t)Data[index++] << 8) |
                                                                 (uint32_t)Data[index++];
            // ��� standard_3_y λ��
            Robot_All_Info.ground_robot_position.standard_3_y = ((uint32_t)Data[index++] << 24) |
                                                                 ((uint32_t)Data[index++] << 16) |
                                                                 ((uint32_t)Data[index++] << 8) |
                                                                 (uint32_t)Data[index++];
            // ��� standard_4_x λ��
            Robot_All_Info.ground_robot_position.standard_4_x = ((uint32_t)Data[index++] << 24) |
                                                                 ((uint32_t)Data[index++] << 16) |
                                                                 ((uint32_t)Data[index++] << 8) |
                                                                 (uint32_t)Data[index++];
            // ��� standard_4_y λ��
            Robot_All_Info.ground_robot_position.standard_4_y = ((uint32_t)Data[index++] << 24) |
                                                                 ((uint32_t)Data[index++] << 16) |
                                                                 ((uint32_t)Data[index++] << 8) |
                                                                 (uint32_t)Data[index++];
            // ��� reserved1 ֵ
            Robot_All_Info.ground_robot_position.reserved1 = ((uint32_t)Data[index++] << 24) |
                                                              ((uint32_t)Data[index++] << 16) |
                                                              ((uint32_t)Data[index++] << 8) |
                                                              (uint32_t)Data[index++];
            // ��� reserved2 ֵ
            Robot_All_Info.ground_robot_position.reserved2 = ((uint32_t)Data[index++] << 24) |
                                                              ((uint32_t)Data[index++] << 16) |
                                                              ((uint32_t)Data[index++] << 8) |
                                                              (uint32_t)Data[index++];
            break;
        case radar_mark_data:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.radar_mark_data.mark_progress = Data[index++];
            break;            

        case sentry_info:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.sentry_info.sentry_info = ((uint32_t)Data[index++] << 24) |
                                                           ((uint32_t)Data[index++] << 16) |
                                                           ((uint32_t)Data[index++] << 8) |
                                                           (uint32_t)Data[index++];
            Robot_All_Info.sentry_info.sentry_info_2 = ((uint16_t)Data[index++] << 8) | (uint16_t)Data[index++];
            break;
        
        case radar_info:
            index = 7;
            // ǿ��ת����uint32_t�Ա������Ͳ�ƥ��
            Robot_All_Info.radar_info.radar_info = Data[index++];
            break;

        default://���������Ҫ��ָ���գ����½���
     memset(Referee_data.Usart6_Rx_Buff, 0, sizeof(Referee_data.Usart6_Rx_Buff));          //��ս��ջ�����
     memset(Referee_data.Usart6_Rx_Buff_Copy, 0, sizeof(Referee_data.Usart6_Rx_Buff_Copy));          //��ս��ջ�����        
     Referee_data.Usart6_Rx_Index = 0; 
     HAL_UART_Receive_DMA(Referee_system_Usart,Referee_data.Usart6_Rx_Buff ,UART6_RX_BUF_SIZE);//����DMA���գ����ڴ�������ϵͳ����
    }//�������Ҫ�����ݣ��������˶���������
     memset(Referee_data.Usart6_Rx_Buff, 0, sizeof(Referee_data.Usart6_Rx_Buff));          //��ս��ջ�����
     memset(Referee_data.Usart6_Rx_Buff_Copy, 0, sizeof(Referee_data.Usart6_Rx_Buff_Copy));          //��ս��ջ�����       
    Referee_data.Usart6_Rx_Index = 0; 
    HAL_UART_Receive_DMA(Referee_system_Usart,Referee_data.Usart6_Rx_Buff ,UART6_RX_BUF_SIZE);//����DMA���գ����ڴ�������ϵͳ����    
}





