#ifndef __GYROSCOPE_H__
#define __GYROSCOPE_H__    
#include "main.h"

#include <stdint.h>

typedef struct
{
 fp32 gyro[3];
 fp32 accel[3];
 fp32 temp; 
 fp32 q[4];
 fp32 INS_angle[3];    
}Gyroscope_Data;
extern Gyroscope_Data Bmi_Data;
void AHRS_init(fp32 quat[4]);
void MahonyAHRSupdateIMU(float q[4], float gx, float gy, float gz, float ax, float ay, float az);
void get_angle(fp32 q[4], fp32 *yaw, fp32 *pitch, fp32 *roll);
#endif


