#include "pid.h"
#include "main.h"
#include "cam.h"
#include "receive.h"
#include "motor.h"
PID_typedef Motor[7];

float Speed_record_A[10];
float Speed_record_B[10];
float Speed_record_C[10];
float Speed_record_D[10];
int test_Speed;


void LimitMax(float *value, float max_limit) {
    if (*value > max_limit) {
        *value = max_limit;  // ���ֵ�������ֵ������Ϊ���ֵ
    } else if (*value < -max_limit) {
        *value = -max_limit; // ���ֵС�ڸ����ֵ������Ϊ�����ֵ
    }
}


void pid_init(PID_typedef *PID,uint8_t mode,float Kp,float Ki,float Kd,float Max_out,float max_iout)
{
        PID->Kp=Kp;
        PID->Ki=Ki;       
        PID->Kd=Kd;     
        PID->Max_out=Max_out;
        PID->Max_iout=max_iout;
        PID->Dout=PID->Iout=PID->OUT=PID->Pout=0;
        PID->error[0]=PID->error[1]=PID->error[2]=PID->D_item=0;
}

float PID_calc(PID_typedef *PID, float measure, float target)
{
	if(PID == NULL)
		return 0;
	PID->error[2] = PID->error[1];
	PID->error[1] = PID->error[0];
	PID->measure = measure;
	PID->target = target;
	PID->error[0] =target - measure;
		if(PID->mode == PID_POSITION_SPEED || PID->mode == PID_POSITION_ANGLE){	
			if(PID->mode == PID_POSITION_ANGLE){
				if(PID->error[0]>4096)	PID->error[0]=PID->error[0]-8191;
				else if(PID->error[0]<-4096)	PID->error[0]=PID->error[0]+8191;
			}
			PID->Pout = PID->Kp * PID->error[0];
			PID->Iout += PID->Ki * PID->error[0];
            PID->Iout=0.30*PID->Iout+0.70*PID->Iout_last;//��ͨ�˲�
			PID->D_item = (PID->error[0] - PID->error[1]);
			PID->Dout = PID->Kd * PID->D_item;
			LimitMax(&PID->Iout,PID->Max_iout);
            PID->Iout_last=PID->Iout;
			PID->OUT = PID->Pout + PID->Iout + PID->Dout;
			LimitMax(&PID->OUT,PID->Max_out);
		}
		else if(PID->mode == PID_DELTA_SPEED){
			PID->Pout = PID->Kp * (PID->error[0] - PID->error[1]);
			PID->Iout = PID->Ki * PID->error[0];
			PID->D_item = (PID->error[0] - 2.0f*PID->error[1] + PID->error[2]);
			PID->Dout = PID->Kd * PID->D_item;
			PID->OUT += PID->Pout + PID->Iout + PID->Dout;
			LimitMax(&PID->OUT, PID->Max_out);
		}
	else{
        PID->OUT=0;
	}
	return PID->OUT;
}

float Speed_Low_Filter(float new_Spe,float *speed_Record)//λ���˲�
{
    float sum = 0.0f;
    test_Speed = new_Spe;
    for(uint8_t i=SPEED_RECORD_NUM-1;i>0;i--)//���������ݺ���һλ
    {
        speed_Record[i] = speed_Record[i-1];
        sum += speed_Record[i-1];
    }
    speed_Record[0] = new_Spe;//��һλ���µ�����
    sum += new_Spe;
    test_Speed = sum/SPEED_RECORD_NUM;
    return sum/SPEED_RECORD_NUM;//���ؾ�ֵ
}

void update_dt7_data(DT7 *dt7_data,float ALPHA) 
    {
    // ����EWMA
    dt7_data->DT7_X_Val = ALPHA * (dt7_data->DT7_X_Val) + (1 - ALPHA) * dt7_data->prev_X_Val;
    dt7_data->DT7_Y_Val = ALPHA * (dt7_data->DT7_Y_Val) + (1 - ALPHA) * dt7_data->prev_Y_Val;
    dt7_data->DT7_Z_Val = ALPHA * (dt7_data->DT7_Z_Val) + (1 - ALPHA) * dt7_data->prev_Z_Val;

    // �����ϴε��˲�ֵ
    dt7_data->prev_X_Val = dt7_data->DT7_X_Val;
    dt7_data->prev_Y_Val = dt7_data->DT7_Y_Val;
    dt7_data->prev_Z_Val = dt7_data->DT7_Z_Val;
}



