#ifndef __PID_H__
#define __PID_H__
#include "main.h"
#define SPEED_RECORD_NUM 10
#include "cam.h"
#include "motor.h"
#include "receive.h"
enum PID_mode {
    PID_POSITION_SPEED,    // λ�ÿ��� - �ٶ�
    PID_POSITION_ANGLE,    // λ�ÿ��� - �Ƕ�
    PID_DELTA_SPEED        // ����ʽ-�ٶ�
};


extern float Speed_record_A[10];//��¼10���ٶ�
extern float Speed_record_B[10];//��¼10���ٶ�
extern float Speed_record_C[10];
extern float Speed_record_D[10];
extern int test_Speed;



typedef struct
{
	enum PID_mode mode;		
	float Kp;
	float Ki;
	float Kd;
	float Max_iout;	
	float Max_out;	
	float measure;
	float target;
	float DeadBand;	
	float Pout;
	float Iout;
    float Iout_last;
	float Dout;
	float D_item;
	float error[3];
	float OUT;
    float CurrenT_Output;//����pid��������
    float CurrenT_Output_Last;  
    float Speed_record[10];//�����˲���¼
}PID_typedef;


extern PID_typedef Motor[7];

void pid_init(PID_typedef *PID,uint8_t mode,float Kp,float Ki,float Kd,float Max_out,float max_iout);
float PID_calc(PID_typedef *PID, float measure, float target);
float Speed_Low_Filter(float new_Spe,float *speed_Record);
void update_dt7_data(DT7 *dt7_data,float ALPHA);

#endif
