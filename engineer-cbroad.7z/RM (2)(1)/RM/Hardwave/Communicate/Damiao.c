#include "Damiao.h"
#include "main.h"
#include "receive.h"
#include "usart.h"


Usart_Damiao_Data Damiao_Data_Rec;

uint8_t Send_Data[30];
uint8_t Send_Data_Index;
void Send_Data_To_Damiao(void)
{
    

      Send_Data[Send_Data_Index++]=0xAA;
      Send_Data[Send_Data_Index++]=0xBB;
      Send_Data[Send_Data_Index++]=(uint8_t)(rc.ch0 & 0xFF);
      Send_Data[Send_Data_Index++]=(uint8_t)((rc.ch0>>8) & 0xFF);
      
      Send_Data[Send_Data_Index++]=(uint8_t)(rc.ch1 & 0xFF);
      Send_Data[Send_Data_Index++]=(uint8_t)((rc.ch1>>8) & 0xFF);
      
      Send_Data[Send_Data_Index++]=(uint8_t)(rc.ch2 & 0xFF);
      Send_Data[Send_Data_Index++]=(uint8_t)((rc.ch2>>8) & 0xFF); 
      
      Send_Data[Send_Data_Index++]=(uint8_t)(rc.ch3 & 0xFF);
      Send_Data[Send_Data_Index++]=(uint8_t)((rc.ch3>>8) & 0xFF);  
      
      Send_Data[Send_Data_Index++]=(uint8_t)(rc.roll & 0xFF);
      Send_Data[Send_Data_Index++]=(uint8_t)((rc.roll>>8) & 0xFF);    

      Send_Data[Send_Data_Index++]=rc.sw1;
      Send_Data[Send_Data_Index++]=rc.sw1;

      Send_Data[Send_Data_Index++]=rc.sw2;
      Send_Data[Send_Data_Index++]=rc.sw2;
      
      Send_Data[Send_Data_Index++]=0x11;
      Send_Data[Send_Data_Index++]=0x11;
      
      
      Send_Data[Send_Data_Index++]=0x22;
      Send_Data[Send_Data_Index++]=0x22;
      
      Send_Data[Send_Data_Index++]=0x33;
      Send_Data[Send_Data_Index++]=0x33;
      
      Send_Data[Send_Data_Index++]=0x44;
      Send_Data[Send_Data_Index++]=0x44;
      
      
      Send_Data[Send_Data_Index++]=0xCC;
      
      
     HAL_UART_Transmit(Damiao_Usart, (uint8_t *)Send_Data, sizeof(Send_Data),0xffff);
}
