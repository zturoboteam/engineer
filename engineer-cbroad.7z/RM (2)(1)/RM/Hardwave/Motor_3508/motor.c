#include "motor.h"
#include "pid.h"
#include "cam.h"
#include "receive.h"
Motor_Output Construction_Car;




//��װ��ʽ
//A   //D
//B   //C

float McNamara_Wheel_Settlement(Motor_Num Motor_Id,MotorMode Install_Mode)
{
    if(Install_Mode==Out_Eight_Mode)
    {
        switch (Motor_Id){
            case MOTOR_A:
                return DT7_Data.DT7_X_Val-DT7_Data.DT7_Y_Val-DT7_Data.DT7_Z_Val;
            case MOTOR_B:
                return DT7_Data.DT7_X_Val+DT7_Data.DT7_Y_Val-DT7_Data.DT7_Z_Val;
            case MOTOR_C:
                return DT7_Data.DT7_X_Val-DT7_Data.DT7_Y_Val+DT7_Data.DT7_Z_Val;
            case MOTOR_D:
                return DT7_Data.DT7_X_Val+DT7_Data.DT7_Y_Val+DT7_Data.DT7_Z_Val;
            default:return 0;
    }
    }
    else if(Install_Mode==IN_Eight_Mode)
    {
        switch (Motor_Id){
            case MOTOR_A:
                return DT7_Data.DT7_X_Val+DT7_Data.DT7_Y_Val-DT7_Data.DT7_Z_Val;
            case MOTOR_B:
                return DT7_Data.DT7_X_Val-DT7_Data.DT7_Y_Val-DT7_Data.DT7_Z_Val;
            case MOTOR_C:
                return DT7_Data.DT7_X_Val+DT7_Data.DT7_Y_Val+DT7_Data.DT7_Z_Val;
            case MOTOR_D:
                return DT7_Data.DT7_X_Val-DT7_Data.DT7_Y_Val+DT7_Data.DT7_Z_Val;
            default:return 0;
    }    
    }
    else
        return 0;
}



