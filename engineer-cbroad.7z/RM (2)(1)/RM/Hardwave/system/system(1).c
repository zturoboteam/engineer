#include "stdio.h"
#include "main.h"
#include "adc.h"
#include "system.h"
#include "receive.h"

void system_init()
{
    HAL_ADC_Start(&hadc1);
    HAL_ADC_Start(&hadc3);
    dbus_uart_init();
}
